package Application;

/*Enum para os status do agendamento, ja que sao status fixos.
* */
public enum StatusAgendamento {
    PENDENTE,
    CONFIRMADO,
    CANCELADO,
    REALIZADO
}
