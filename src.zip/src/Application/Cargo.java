package Application;

public enum Cargo {
    VETERINARIO,
    RECEPCIONISTA,
    AUXILIAR,
    MANUNTENCAO,
}
