package Main;

import Entities.Animais;
import Entities.Cliente;
import Repositories.IClienteRepository;


public class Main {
    public static void main(String[] args) {

    }
}